# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['scripts']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp>=3.8.3,<4.0.0']

entry_points = \
{'console_scripts': ['json-processor = '
                     'scripts.processor:json_processor_runner']}

setup_kwargs = {
    'name': 'json-proccesor',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Ruslan Akhmetshin',
    'author_email': 'sccrsccr1@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
